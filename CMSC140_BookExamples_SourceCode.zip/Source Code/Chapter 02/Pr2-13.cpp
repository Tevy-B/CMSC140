// This program demonstrates the close relationship between
// characters and integers.
#include <iostream>
using namespace std;

int main()
{
   char letter;

   letter = 65;
   cout << letter << endl;
   letter = 66;
   cout << letter << endl;
   return 0;
} 