// A simple C++ program
#include <iostream>
using namespace std;

int main()
{
   cout << "Programming is " << "great fun!";
   return 0;
} 