// PROGRAM: PAYROLL.CPP
// Written by Herbert Dorfmann
// This program calculates company payroll
// Last modification: 8/20/2008
#include <iostream>
using namespace std;

int main()
{
   double payRate;   // Holds the hourly pay rate
   double hours;     // Holds the hours worked
   int employNumber; // Holds the employee number

   // The remainder of this program is left out.

   return 0;
}