// This program demonstrates a simple while loop.
#include <iostream>
using namespace std;

int main()
{
   int number = 0;

   while (number < 5)
   {
      cout << "Hello\n";
      number++;
   }
   cout << "That's all!\n";
   return 0;
}